package com.durgesh.mongodb.mongodbexample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MongodbExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
