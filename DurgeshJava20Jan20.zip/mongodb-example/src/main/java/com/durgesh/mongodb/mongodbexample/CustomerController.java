package com.durgesh.mongodb.mongodbexample;

import java.util.List;
import java.util.Optional;

import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CustomerController {

	@Autowired
	private CustomerRepository customerRepository;
	
	@GetMapping("/customer")
	public List<Customer> retrieveCustomers()
	{
		return customerRepository.findAll();
	}
	
	@GetMapping("/customer/{customerid}")
	public Customer retrieveCustomersById(@PathVariable ObjectId customerid)
	{
		return customerRepository.findBy_id(customerid);
	}
	
	@PostMapping("/customer")
	public Customer addCustomers(@RequestBody Customer customer)
	{
		customer.set_id(ObjectId.get());
		customerRepository.save(customer);
		return customer;
	}
	
	@PutMapping("/customer/{id}")
	public Customer updateCustomers(@PathVariable ObjectId id, @RequestBody Customer customer)
	{
		customer.set_id(id);
		customerRepository.save(customer);
		return customer;
	}
	
	@DeleteMapping("/customer/{id}")
	public void deleteCustomerById(@PathVariable ObjectId id)
	{
		customerRepository.delete(customerRepository.findBy_id(id));
	}
}
