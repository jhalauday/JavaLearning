package com.durgesh.mongodb.mongodbexample;


import org.bson.types.ObjectId;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class Customer {

	@org.springframework.data.annotation.Id
	private ObjectId _id;
	
	private String name;
	
	private String location;




	public ObjectId get_id() {
		return _id;
	}

	public void set_id(ObjectId _id) {
		this._id = _id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public Customer() {
		super();
	}

	public Customer(ObjectId _id, String name, String location) {
		super();
		this._id = _id;
		this.name = name;
		this.location = location;
	}

	@Override
	public String toString() {
		return "Customer [_id=" + _id + ", name=" + name + ", location=" + location + "]";
	}
	

	
}
