package com.durgesh.mongodb.mongodbexample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MongodbExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(MongodbExampleApplication.class, args);
	}

}
