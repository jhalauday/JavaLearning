package com.durgesh.mongodb.mongodbexample;

import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface CustomerRepository extends MongoRepository<Customer, Integer>{

	Customer findBy_id(ObjectId _id);
}
