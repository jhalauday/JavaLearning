insert into exchange_value(id,country_from,country_to,conversion_multiple,port)
values(10001,'USD','INR',65,0);
insert into exchange_value(id,country_from,country_to,conversion_multiple,port)
values(10002,'EUR','INR',90,0);