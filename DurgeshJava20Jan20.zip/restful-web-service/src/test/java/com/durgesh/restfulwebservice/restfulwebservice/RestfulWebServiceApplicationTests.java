package com.durgesh.restfulwebservice.restfulwebservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestfulWebServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
