package com.durgesh.restfulwebservice.restfulwebservice.helloworld;

public class HelloWorldBean {

	private String message;

	public String getName() {
		return message;
	}

	public void setName(String message) {
		this.message = message;
	}

	public HelloWorldBean(String message) {
		super();
		this.message = message;
	}

	@Override
	public String toString() {
		return "HelloWorldBean [message=" + message + "]";
	}


}
