package com.durgesh.restfulwebservice.restfulwebservice.user;

//import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

import java.net.URI;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.hateoas.EntityModel;
//import org.springframework.hateoas.RepresentationModel;
//import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

@RestController
public class UserController {

	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private PostRepository postRepository;
	
	@GetMapping("/users")
	public List<User> showAllUser()
	{
		//return new User();
		return userRepository.findAll();
	}
	
	@GetMapping("/users/{id}")
	public Optional<User> showUserById(@PathVariable Integer id)
	{

		Optional<User> user =userRepository.findById(id);
		
		if (!user.isPresent())
			throw new UserNotFoundException("id-" + id);
			
			// "all-users", SERVER_PATH + "/users"
			// retrieveAllUsers
			

		//EntityModel<User> model = new EntityModel<User>();
		//RepresentationModel<User> model = new RepresentationModel<>();
		//WebMvcLinkBuilder linkTo = linkTo(methodOn(this.getClass()).showAllUser());
		//model.add(linkTo.withRel("all-users")); 

			// HATEOAS
		//Resource<User> resource = new Resource<User>(user);
		//ControllerLinkBuilder linkTo = linkTo(methodOn(this.getClass()).retrieveAllUsers());
		//resource.add(linkTo.withRel("all-users")); 
		
		return user;
	}
	
	@DeleteMapping("/users/{id}")
	public void deleteUser(@PathVariable Integer id) {
		userRepository.deleteById(id);
	}
	
	@PostMapping("/users")
	public ResponseEntity<Object> createUser(@Valid @RequestBody User user) {
		User savedUser = userRepository.save(user);

		URI location = ServletUriComponentsBuilder.fromCurrentRequest()
				.path("/{id}").buildAndExpand(savedUser.getId()).toUri();
		return ResponseEntity.created(location).build();

	}
	
	//Retrieve all posts for a User - GET /users/{id}/posts

	//Create a posts for a User - POST /users/{id}/posts

	//Retrieve details of a post - GET /users/{id}/posts/{post_id}
	
	@GetMapping("/users/{id}/posts")
	public List<Post> showPostByUserId(@PathVariable Integer id)
	{

		Optional<User> user =userRepository.findById(id);
				
		if (!user.isPresent())
			throw new UserNotFoundException("id-" + id);
			
		return user.get().getPosts();
	}
	
	@GetMapping("/users/{user_id}/posts/{post_id}")
	public Optional<Post> showPostById(@PathVariable Integer user_id, @PathVariable Integer post_id)
	{
		
		Optional<User> user =userRepository.findById(user_id);
		
		Optional<Post> post1 =postRepository.findById(post_id);
		
					
		if (!user.isPresent())
			throw new UserNotFoundException("user id-" + user_id);
		
		if (!post1.isPresent())
			throw new UserNotFoundException("post id-" + post_id);
		
		
		return postRepository.findByIdAndUserId(post_id,user_id);
		
				
	}
	
	@PostMapping("/users/{id}/posts")
	public ResponseEntity<Object> createPost(@PathVariable int id, @RequestBody Post post) {
		
		Optional<User> userOptional = userRepository.findById(id);
		
		if(!userOptional.isPresent()) {
			throw new UserNotFoundException("id-" + id);
		}

		User user = userOptional.get();
		
		post.setUser(user);
		
		postRepository.save(post);
		
		URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(post.getId())
				.toUri();

		return ResponseEntity.created(location).build();
		
		//this is a test comment 
		
	}
}
